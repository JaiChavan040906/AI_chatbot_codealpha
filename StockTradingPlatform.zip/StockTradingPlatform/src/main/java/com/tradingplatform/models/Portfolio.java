package com.tradingplatform.models;

import java.util.HashMap;
import java.util.Map;

public class Portfolio {
    private Map<String, Integer> holdings = new HashMap<>();

    public Map<String, Integer> getHoldings() { return holdings; }

    public void addStock(String symbol, int quantity) {
        holdings.put(symbol, holdings.getOrDefault(symbol, 0) + quantity);
    }

    public void removeStock(String symbol, int quantity) {
        if (holdings.containsKey(symbol)) {
            holdings.put(symbol, holdings.get(symbol) - quantity);
            if (holdings.get(symbol) <= 0) holdings.remove(symbol);
        }
    }
}
