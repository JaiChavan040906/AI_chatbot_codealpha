package com.tradingplatform.services;

import com.tradingplatform.models.*;

public class TransactionService {

    public void buyStock(User user, String symbol, int quantity, MarketService marketService, PortfolioService portfolioService) {
        Stock stock = marketService.getStock(symbol);
        if (stock == null) {
            System.out.println("Stock not found.");
            return;
        }
        double totalCost = stock.getPrice() * quantity;
        if (user.getBalance() >= totalCost) {
            user.setBalance(user.getBalance() - totalCost);
            user.getPortfolio().addStock(symbol, quantity);
            user.getTransactions().add(new Transaction(symbol, quantity, stock.getPrice(), "BUY"));
            System.out.println("Bought " + quantity + " shares of " + symbol);
        } else {
            System.out.println("Insufficient funds.");
        }
    }

    public void sellStock(User user, String symbol, int quantity, MarketService marketService, PortfolioService portfolioService) {
        if (!user.getPortfolio().getHoldings().containsKey(symbol) ||
                user.getPortfolio().getHoldings().get(symbol) < quantity) {
            System.out.println("Not enough shares to sell.");
            return;
        }
        Stock stock = marketService.getStock(symbol);
        if (stock == null) {
            System.out.println("Stock not found.");
            return;
        }
        double totalValue = stock.getPrice() * quantity;
        user.setBalance(user.getBalance() + totalValue);
        user.getPortfolio().removeStock(symbol, quantity);
        user.getTransactions().add(new Transaction(symbol, quantity, stock.getPrice(), "SELL"));
        System.out.println("Sold " + quantity + " shares of " + symbol);
    }
}
