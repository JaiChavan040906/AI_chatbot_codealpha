package com.tradingplatform.services;

import com.tradingplatform.models.Stock;
import java.util.HashMap;
import java.util.Map;

public class MarketService {
    private Map<String, Stock> marketData = new HashMap<>();

    public MarketService() {
        marketData.put("AAPL", new Stock("AAPL", "Apple Inc.", 180.0));
        marketData.put("GOOG", new Stock("GOOG", "Alphabet Inc.", 2700.0));
        marketData.put("TSLA", new Stock("TSLA", "Tesla Inc.", 750.0));
    }

    public void displayMarketData() {
        System.out.println("\n--- Market Data ---");
        for (Stock stock : marketData.values()) {
            System.out.println(stock.getSymbol() + " - " + stock.getName() + " - $" + stock.getPrice());
        }
    }

    public Stock getStock(String symbol) {
        return marketData.get(symbol);
    }
}
