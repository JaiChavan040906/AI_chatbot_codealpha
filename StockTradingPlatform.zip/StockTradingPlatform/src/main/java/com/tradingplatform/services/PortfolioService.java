package com.tradingplatform.services;

import com.tradingplatform.models.*;

public class PortfolioService {

    public void displayPortfolio(User user) {
        System.out.println("\n--- Portfolio ---");
        user.getPortfolio().getHoldings().forEach((symbol, qty) ->
                System.out.println(symbol + ": " + qty));
        System.out.println("Balance: $" + user.getBalance());
    }
}
