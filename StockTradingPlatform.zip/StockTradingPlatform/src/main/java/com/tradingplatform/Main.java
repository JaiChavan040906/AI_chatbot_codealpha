package com.tradingplatform;

import com.tradingplatform.models.*;
import com.tradingplatform.services.*;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        MarketService marketService = new MarketService();
        PortfolioService portfolioService = new PortfolioService();
        TransactionService transactionService = new TransactionService();

        User user = new User("John Doe", 10000);
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\n--- Stock Trading Platform ---");
            System.out.println("1. View Market Data");
            System.out.println("2. Buy Stock");
            System.out.println("3. Sell Stock");
            System.out.println("4. View Portfolio");
            System.out.println("5. Exit");
            System.out.print("Choose an option: ");

            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1 -> marketService.displayMarketData();
                case 2 -> {
                    System.out.print("Enter stock symbol: ");
                    String buySymbol = scanner.nextLine();
                    System.out.print("Enter quantity: ");
                    int buyQty = scanner.nextInt();
                    transactionService.buyStock(user, buySymbol, buyQty, marketService, portfolioService);
                }
                case 3 -> {
                    System.out.print("Enter stock symbol: ");
                    String sellSymbol = scanner.nextLine();
                    System.out.print("Enter quantity: ");
                    int sellQty = scanner.nextInt();
                    transactionService.sellStock(user, sellSymbol, sellQty, marketService, portfolioService);
                }
                case 4 -> portfolioService.displayPortfolio(user);
                case 5 -> {
                    System.out.println("Exiting...");
                    return;
                }
                default -> System.out.println("Invalid choice. Try again.");
            }
        }
    }
}
