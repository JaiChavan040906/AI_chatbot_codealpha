package chatbot;

import chatbot.nlp.SimpleNLP;
import chatbot.responses.ResponseGenerator;

public class ChatBot {
    private final SimpleNLP nlp;
    private final ResponseGenerator responseGenerator;

    public ChatBot() {
        this.nlp = new SimpleNLP();
        this.responseGenerator = new ResponseGenerator();
    }

    public String getResponse(String input) {
        String intent = nlp.detectIntent(input);
        return responseGenerator.generateResponse(intent, input);
    }
}
