package chatbot;

import chatbot.gui.ChatFrame;

public class Main {
    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(ChatFrame::new);
    }
}
