package chatbot.gui;

import javax.swing.*;
import java.awt.*;
import java.net.URL;

public class MessagePanel extends JPanel {
    private final JPanel chats;

    public MessagePanel() {
        setLayout(new BorderLayout());
        setBackground(new Color(30, 30, 30));
        chats = new JPanel();
        chats.setBackground(new Color(30, 30, 30));
        chats.setLayout(new BoxLayout(chats, BoxLayout.Y_AXIS));
        add(chats, BorderLayout.NORTH);
    }

    public void addUserMessage(String message) {
        JPanel bubble = createBubble(message, Color.CYAN, true, null);
        chats.add(bubble);
        updatePanel();
    }

    public void addBotMessage(String message) {
        URL botIconUrl = getClass().getResource("/images/bot_icon.png");
        ImageIcon icon = botIconUrl != null ? new ImageIcon(botIconUrl) : null;
        JPanel bubble = createBubble(message, new Color(80, 80, 90), false, icon);
        chats.add(bubble);
        updatePanel();
    }

    private JPanel createBubble(String message, Color color, boolean rightAlign, Icon icon) {
        JPanel bubble = new JPanel();
        bubble.setLayout(new FlowLayout(rightAlign ? FlowLayout.RIGHT : FlowLayout.LEFT));
        bubble.setBackground(Color.BLACK);
        JLabel label = new JLabel("<html><p style='width: 300px;'>" + message + "</p></html>");
        label.setOpaque(true);
        label.setBackground(color);
        label.setForeground(Color.BLACK);
        label.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        label.setBorder(BorderFactory.createEmptyBorder(12, 16, 12, 16));
        label.setAlignmentY(Component.TOP_ALIGNMENT);

        if (icon != null) {
            JLabel iconLabel = new JLabel(icon);
            JPanel msgPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
            msgPanel.setBackground(Color.BLACK);
            msgPanel.add(iconLabel);
            msgPanel.add(Box.createHorizontalStrut(8));
            msgPanel.add(label);
            bubble.add(msgPanel);
        } else {
            bubble.add(label);
        }
        return bubble;
    }

    private void updatePanel() {
        revalidate();
        repaint();
        getParent().revalidate();
        JScrollPane scroll = (JScrollPane) SwingUtilities.getAncestorOfClass(JScrollPane.class, this);
        if (scroll != null) {
            JScrollBar vertical = scroll.getVerticalScrollBar();
            vertical.setValue(vertical.getMaximum());
        }
    }
}
