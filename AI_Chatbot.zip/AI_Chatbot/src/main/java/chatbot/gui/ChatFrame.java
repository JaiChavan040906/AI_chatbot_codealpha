package chatbot.gui;

import chatbot.ChatBot;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.net.URL;

public class ChatFrame extends JFrame {
    private final ChatBot bot;
    private final MessagePanel messagePanel;
    private final JTextField inputField;
    private final JButton sendButton;

    public ChatFrame() {
        super("AI Chatbot - Dark Theme");
        this.bot = new ChatBot();

        // Set up frame
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(520, 600);
        setLayout(new BorderLayout());
        setResizable(false);

        // Message panel (chat area)
        messagePanel = new MessagePanel();
        JScrollPane scrollPane = new JScrollPane(messagePanel,
                JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.setBorder(null);

        // Input area
        inputField = new JTextField();
        inputField.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        inputField.setForeground(Color.WHITE);
        inputField.setBackground(new Color(40, 40, 40));
        inputField.setCaretColor(Color.WHITE);
        inputField.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Send button with icon
        sendButton = new JButton();
        sendButton.setBackground(new Color(60, 60, 70));
        sendButton.setBorderPainted(false);
        sendButton.setFocusPainted(false);
        sendButton.setPreferredSize(new Dimension(48, 48));
        sendButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        try {
            URL iconURL = getClass().getResource("/images/send_icon.png");
            if (iconURL != null)
                sendButton.setIcon(new ImageIcon(iconURL));
        } catch (Exception ignored) {}

        JPanel inputPanel = new JPanel(new BorderLayout());
        inputPanel.setBackground(new Color(30, 30, 30));
        inputPanel.add(inputField, BorderLayout.CENTER);
        inputPanel.add(sendButton, BorderLayout.EAST);

        add(scrollPane, BorderLayout.CENTER);
        add(inputPanel, BorderLayout.SOUTH);

        // Event
        ActionListener sendAction = e -> sendMessage();
        sendButton.addActionListener(sendAction);
        inputField.addActionListener(sendAction);

        // Greeting
        messagePanel.addBotMessage("Hi! I'm your AI Chatbot. How can I assist you today?");

        setVisible(true);
    }

    private void sendMessage() {
        String userInput = inputField.getText().trim();
        if (!userInput.isEmpty()) {
            messagePanel.addUserMessage(userInput);
            SwingUtilities.invokeLater(() -> {
                String response = bot.getResponse(userInput);
                messagePanel.addBotMessage(response);
            });
            inputField.setText("");
        }
    }
}
