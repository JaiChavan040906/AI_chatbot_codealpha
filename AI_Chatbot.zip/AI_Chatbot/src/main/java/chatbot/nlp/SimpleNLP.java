package chatbot.nlp;

public class SimpleNLP {
    public String detectIntent(String input) {
        String text = input.trim().toLowerCase();
        if (text.contains("hello") || text.contains("hi") || text.contains("hey")) return "greeting";
        if (text.contains("help") || text.contains("support")) return "help";
        if (text.contains("your name")) return "name";
        if (text.matches(".*(bye|exit|quit|goodbye).*")) return "bye";
        if (text.contains("how are you")) return "feeling";
        if (text.contains("weather")) return "weather";
        if (text.contains("thanks") || text.contains("thank you")) return "thanks";
        return "unknown";
    }
}
