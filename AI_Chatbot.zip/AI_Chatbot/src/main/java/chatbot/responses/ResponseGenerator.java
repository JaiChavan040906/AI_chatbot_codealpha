package chatbot.responses;

import java.util.Random;

public class ResponseGenerator {
    private final Random random = new Random();

    public String generateResponse(String intent, String input) {
        switch (intent) {
            case "greeting":
                return getRandom(new String[]{
                        "Hello! 👋", "Hi there!", "Hey! How can I help you today?"
                });
            case "help":
                return "You can ask me questions related to FAQs or just chat!";
            case "name":
                return "I'm your AI Chatbot, here to assist you.";
            case "bye":
                return "Goodbye! Have a great day!";
            case "feeling":
                return "I'm just a bunch of code, but I'm ready to help!";
            case "weather":
                return "I can't fetch live weather yet, but it's always a good day to chat!";
            case "thanks":
                return getRandom(new String[]{
                        "You're welcome!", "Glad to help!", "Anytime! 😊"
                });
            default:
                return getRandom(new String[]{
                        "Interesting... Tell me more!",
                        "I'm sorry, I didn't catch that. Can you rephrase?",
                        "Let's talk more, I'm learning every day!"
                });
        }
    }

    private String getRandom(String[] responses) {
        return responses[random.nextInt(responses.length)];
    }
}

