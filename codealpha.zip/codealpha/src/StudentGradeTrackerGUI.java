import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;

public class StudentGradeTrackerGUI extends JFrame {
    static class Student {
        String name;
        double marks;
        String grade;

        Student(String name, double marks, String grade) {
            this.name = name;
            this.marks = marks;
            this.grade = grade;
        }
    }

    private ArrayList<Student> students;
    private JTable table;
    private DefaultTableModel tableModel;

    public StudentGradeTrackerGUI() {
        students = new ArrayList<>();
        setTitle("Student Grade Tracker");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Dark mode colors
        Color bgColor = new Color(35, 35, 35);
        Color fgColor = new Color(220, 220, 220);
        Color accentColor = new Color(70, 130, 180);

        // Table for student list
        String[] columnNames = {"Name", "Marks", "Grade"};
        tableModel = new DefaultTableModel(columnNames, 0);
        table = new JTable(tableModel);
        table.setBackground(bgColor);
        table.setForeground(fgColor);
        table.setGridColor(new Color(70, 70, 70));
        table.setRowHeight(25);
        table.setFont(new Font("SansSerif", Font.PLAIN, 14));
        table.getTableHeader().setBackground(accentColor);
        table.getTableHeader().setForeground(Color.WHITE);
        table.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 14));

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.getViewport().setBackground(bgColor);
        add(scrollPane, BorderLayout.CENTER);

        // Toolbar with buttons
        JToolBar toolBar = new JToolBar();
        toolBar.setFloatable(false);
        toolBar.setBackground(bgColor);

        JButton addButton = createStyledButton("➕ Add Student", accentColor, fgColor);
        JButton summaryButton = createStyledButton("📊 Show Summary", accentColor, fgColor);
        JButton exitButton = createStyledButton("❌ Exit", new Color(200, 60, 60), fgColor);

        toolBar.add(addButton);
        toolBar.add(summaryButton);
        toolBar.add(exitButton);

        add(toolBar, BorderLayout.NORTH);

        // Actions
        addButton.addActionListener(e -> addStudent());
        summaryButton.addActionListener(e -> showSummary());
        exitButton.addActionListener(e -> System.exit(0));
    }

    private JButton createStyledButton(String text, Color bg, Color fg) {
        JButton btn = new JButton(text);
        btn.setFocusPainted(false);
        btn.setBackground(bg);
        btn.setForeground(fg);
        btn.setFont(new Font("SansSerif", Font.BOLD, 13));
        btn.setBorder(BorderFactory.createEmptyBorder(5, 15, 5, 15));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        // Hover effect
        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btn.setBackground(bg.darker());
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btn.setBackground(bg);
            }
        });
        return btn;
    }

    private void addStudent() {
        String name = JOptionPane.showInputDialog(this, "Enter student name:");
        if (name == null || name.trim().isEmpty()) return;

        String marksInput = JOptionPane.showInputDialog(this, "Enter marks (0-100):");
        if (marksInput == null || marksInput.trim().isEmpty()) return;

        try {
            double marks = Double.parseDouble(marksInput);
            if (marks < 0 || marks > 100) {
                JOptionPane.showMessageDialog(this, "Marks must be between 0 and 100.");
                return;
            }

            String grade = assignGrade(marks);
            students.add(new Student(name, marks, grade));
            tableModel.addRow(new Object[]{name, marks, grade});

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid marks. Please enter a number.");
        }
    }

    private String assignGrade(double marks) {
        if (marks >= 90) return "A";
        else if (marks >= 80) return "B";
        else if (marks >= 70) return "C";
        else if (marks >= 60) return "D";
        else if (marks >= 50) return "E";
        else return "F";
    }

    private void showSummary() {
        if (students.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No students entered yet.");
            return;
        }

        double total = 0, highest = students.get(0).marks, lowest = students.get(0).marks;
        Student topStudent = students.get(0), lowStudent = students.get(0);

        for (Student s : students) {
            total += s.marks;
            if (s.marks > highest) { highest = s.marks; topStudent = s; }
            if (s.marks < lowest) { lowest = s.marks; lowStudent = s; }
        }

        double average = total / students.size();
        String summary = String.format(
                "Total Students: %d\nAverage Marks: %.2f\nHighest: %s (%.2f, Grade %s)\nLowest: %s (%.2f, Grade %s)",
                students.size(), average,
                topStudent.name, topStudent.marks, topStudent.grade,
                lowStudent.name, lowStudent.marks, lowStudent.grade
        );

        JOptionPane.showMessageDialog(this, summary, "Summary Report", JOptionPane.INFORMATION_MESSAGE);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            StudentGradeTrackerGUI tracker = new StudentGradeTrackerGUI();
            tracker.setVisible(true);
        });
    }
}
